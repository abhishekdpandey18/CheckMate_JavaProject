package com.chess.GUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.sql.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.chess.GUI.Table.MoveLog;
import com.chess.engine.board.Board;
import com.chess.engine.board.Move;
import com.chess.database.DatabaseConnection;

public class GameHistoryPanel extends JPanel {

	private final DataModel model;
	private final JScrollPane scrollPane;
	private static final Dimension HISTORY_PANEL_DIMENSION = new Dimension(100, 400);

	GameHistoryPanel() {
		this.setLayout(new BorderLayout());
		this.model = new DataModel();
		final JTable table = new JTable(model);
		table.setRowHeight(15);
		this.scrollPane = new JScrollPane(table);
		scrollPane.setColumnHeaderView(table.getTableHeader());
		scrollPane.setPreferredSize(HISTORY_PANEL_DIMENSION);
		this.add(scrollPane, BorderLayout.CENTER);
		this.setVisible(true);
	}

	void redo(final Board board, final MoveLog moveHistory) {
		List<String> whiteMoves = new ArrayList<>();
		List<String> blackMoves = new ArrayList<>();

		for (final Move move : moveHistory.getMoves()) {
			final String moveText = move.toString();
			if (move.getMovedPiece().getPieceAlliance().isWhite()) {
				whiteMoves.add(moveText);
			} else if (move.getMovedPiece().getPieceAlliance().isBlack()) {
				blackMoves.add(moveText);
			}
		}

		int totalMoves = Math.max(whiteMoves.size(), blackMoves.size());
		this.model.clear();

		for (int i = 0; i < totalMoves; i++) {
			String whiteMove = i < whiteMoves.size() ? whiteMoves.get(i) : "";
			String blackMove = i < blackMoves.size() ? blackMoves.get(i) : "";

			this.model.setValueAt(whiteMove, i, 0);
			this.model.setValueAt(blackMove, i, 1);

			saveMoveToDatabase(i + 1, whiteMove, blackMove);
		}

		if (!moveHistory.getMoves().isEmpty()) {
			final Move lastMove = moveHistory.getMoves().get(moveHistory.size() - 1);
			final String moveText = lastMove.toString();
			final String annotation = calculateCheckAndCheckMateHash(board);
			if (lastMove.getMovedPiece().getPieceAlliance().isWhite()) {
				this.model.setValueAt(moveText + annotation, totalMoves, 0);
			} else {
				this.model.setValueAt(moveText + annotation, totalMoves - 1, 1);
			}
		}

		final JScrollBar vertical = scrollPane.getVerticalScrollBar();
		vertical.setValue(vertical.getMaximum());
	}

	private String calculateCheckAndCheckMateHash(final Board board) {
		if (board.currentPlayer().isInCheckMate()) {
			return "#";
		} else if (board.currentPlayer().isInCheck()) {
			return "+";
		}
		return "";
	}

	private void saveMoveToDatabase(final int moveNumber, final String whiteMove, final String blackMove) {
		String sql = "INSERT INTO move_history (move_number, white_move, black_move) VALUES (?, ?, ?)";

		try (Connection conn = DatabaseConnection.getConnection();
			 PreparedStatement stmt = conn.prepareStatement(sql)) {

			stmt.setInt(1, moveNumber);
			stmt.setString(2, whiteMove);
			stmt.setString(3, blackMove);
			stmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Load and display moves from the last saved game
	public void loadGameFromDatabase() {
		String sql = "SELECT move_number, white_move, black_move FROM move_history ORDER BY move_number ASC";

		this.model.clear();
		try (Connection conn = DatabaseConnection.getConnection();
			 PreparedStatement stmt = conn.prepareStatement(sql);
			 ResultSet rs = stmt.executeQuery()) {

			while (rs.next()) {
				int moveNumber = rs.getInt("move_number");
				String whiteMove = rs.getString("white_move");
				String blackMove = rs.getString("black_move");
				this.model.setValueAt(whiteMove, moveNumber - 1, 0);
				this.model.setValueAt(blackMove, moveNumber - 1, 1);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static class DataModel extends DefaultTableModel {

		private final List<Row> values;
		private static final String[] NAMES = {"White", "Black"};

		DataModel() {
			this.values = new ArrayList<>();
		}

		public void clear() {
			this.values.clear();
			setRowCount(0);
		}

		@Override
		public int getRowCount() {
			return this.values == null ? 0 : this.values.size();
		}

		@Override
		public int getColumnCount() {
			return NAMES.length;
		}

		@Override
		public Object getValueAt(final int row, final int column) {
			final Row currentRow = this.values.get(row);
			return (column == 0) ? currentRow.getWhiteMove() : currentRow.getBlackMove();
		}

		@Override
		public void setValueAt(final Object aValue, final int row, final int column) {
			Row currentRow;
			if (this.values.size() <= row) {
				currentRow = new Row();
				this.values.add(currentRow);
			} else {
				currentRow = this.values.get(row);
			}
			if (column == 0) {
				currentRow.setWhiteMove((String) aValue);
				fireTableRowsInserted(row, row);
			} else if (column == 1) {
				currentRow.setBlackMove((String) aValue);
				fireTableCellUpdated(row, column);
			}
		}

		@Override
		public Class<?> getColumnClass(final int column) {
			return Move.class;
		}

		@Override
		public String getColumnName(final int column) {
			return NAMES[column];
		}
	}

	private static class Row {

		private String whiteMove;
		private String blackMove;

		public String getWhiteMove() {
			return this.whiteMove;
		}

		public String getBlackMove() {
			return this.blackMove;
		}

		public void setWhiteMove(final String move) {
			this.whiteMove = move;
		}

		public void setBlackMove(final String move) {
			this.blackMove = move;
		}
	}
}
