package com.chess.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/chessdb"; // Your DB URL
    private static final String USER = "root";                                // Your DB user
    private static final String PASSWORD = "yourpassword";                    // Your DB password

    private static Connection connection;

    // Static block to initialize the connection
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Load the driver
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("✅ Database connected successfully.");
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("❌ Failed to connect to database.");
            e.printStackTrace();
        }
    }

    // Method to get the connection
    public static Connection getConnection() {
        return connection;
    }
}
